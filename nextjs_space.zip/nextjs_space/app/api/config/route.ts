import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import prisma from '@/lib/prisma';

export const dynamic = 'force-dynamic';

export async function GET() {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ error: 'No autorizado' }, { status: 401 });

  try {
    const [pointsConfig, tierConfig] = await Promise.all([
      prisma.pointsConfig.findMany({ orderBy: { fuelType: 'asc' } }),
      prisma.tierConfig.findMany({ orderBy: { minPoints: 'asc' } }),
    ]);
    return NextResponse.json({ pointsConfig, tierConfig });
  } catch (error) {
    console.error('Config GET error:', error);
    return NextResponse.json({ error: 'Error al obtener configuración' }, { status: 500 });
  }
}

export async function PUT(req: NextRequest) {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ error: 'No autorizado' }, { status: 401 });

  try {
    const body = await req.json();
    const { pointsConfig, tierConfig } = body;

    if (pointsConfig) {
      for (const pc of pointsConfig) {
        await prisma.pointsConfig.upsert({
          where: { fuelType: pc.fuelType },
          update: { pointsPerQuetzal: parseFloat(pc.pointsPerQuetzal), description: pc.description },
          create: { fuelType: pc.fuelType, pointsPerQuetzal: parseFloat(pc.pointsPerQuetzal), description: pc.description },
        });
      }
    }

    if (tierConfig) {
      for (const tc of tierConfig) {
        await prisma.tierConfig.upsert({
          where: { name: tc.name },
          update: { minPoints: parseInt(tc.minPoints), multiplier: parseFloat(tc.multiplier), color: tc.color, benefits: tc.benefits },
          create: { name: tc.name, minPoints: parseInt(tc.minPoints), multiplier: parseFloat(tc.multiplier), color: tc.color, benefits: tc.benefits },
        });
      }
    }

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Config PUT error:', error);
    return NextResponse.json({ error: 'Error al actualizar configuración' }, { status: 500 });
  }
}
