import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import prisma from '@/lib/prisma';

export const dynamic = 'force-dynamic';

export async function PUT(req: NextRequest, { params }: { params: { id: string } }) {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ error: 'No autorizado' }, { status: 401 });

  try {
    const body = await req.json();
    const promotion = await prisma.promotion.update({
      where: { id: params.id },
      data: {
        name: body.name,
        description: body.description,
        type: body.type,
        multiplier: body.multiplier ? parseFloat(body.multiplier) : undefined,
        bonusPoints: body.bonusPoints !== undefined ? parseInt(body.bonusPoints) : undefined,
        minAmount: body.minAmount ? parseFloat(body.minAmount) : null,
        fuelType: body.fuelType || null,
        stationId: body.stationId || null,
        isActive: body.isActive,
        startDate: body.startDate ? new Date(body.startDate) : undefined,
        endDate: body.endDate ? new Date(body.endDate) : undefined,
      },
    });
    return NextResponse.json(promotion);
  } catch (error) {
    console.error('Promotion PUT error:', error);
    return NextResponse.json({ error: 'Error al actualizar promoción' }, { status: 500 });
  }
}

export async function DELETE(req: NextRequest, { params }: { params: { id: string } }) {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ error: 'No autorizado' }, { status: 401 });

  try {
    await prisma.promotion.delete({ where: { id: params.id } });
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Promotion DELETE error:', error);
    return NextResponse.json({ error: 'Error al eliminar promoción' }, { status: 500 });
  }
}
