import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import prisma from '@/lib/prisma';

export const dynamic = 'force-dynamic';

export async function GET() {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ error: 'No autorizado' }, { status: 401 });

  try {
    const promotions = await prisma.promotion.findMany({
      orderBy: { createdAt: 'desc' },
      include: { station: { select: { name: true } } },
    });
    return NextResponse.json(promotions);
  } catch (error) {
    console.error('Promotions GET error:', error);
    return NextResponse.json({ error: 'Error al obtener promociones' }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ error: 'No autorizado' }, { status: 401 });

  try {
    const body = await req.json();
    const { name, description, type, multiplier, bonusPoints, minAmount, fuelType, stationId, startDate, endDate } = body;

    if (!name || !type || !startDate || !endDate) {
      return NextResponse.json({ error: 'Nombre, tipo, fecha inicio y fin son requeridos' }, { status: 400 });
    }

    const promotion = await prisma.promotion.create({
      data: {
        name,
        description,
        type,
        multiplier: multiplier ? parseFloat(multiplier) : 1,
        bonusPoints: bonusPoints ? parseInt(bonusPoints) : 0,
        minAmount: minAmount ? parseFloat(minAmount) : null,
        fuelType: fuelType || null,
        stationId: stationId || null,
        startDate: new Date(startDate),
        endDate: new Date(endDate),
      },
    });
    return NextResponse.json(promotion, { status: 201 });
  } catch (error) {
    console.error('Promotions POST error:', error);
    return NextResponse.json({ error: 'Error al crear promoción' }, { status: 500 });
  }
}
