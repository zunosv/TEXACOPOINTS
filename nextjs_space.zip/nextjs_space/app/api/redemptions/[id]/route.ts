import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import prisma from '@/lib/prisma';

export const dynamic = 'force-dynamic';

export async function PUT(req: NextRequest, { params }: { params: { id: string } }) {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ error: 'No autorizado' }, { status: 401 });

  try {
    const body = await req.json();
    const { status } = body;

    if (!['COMPLETED', 'CANCELLED'].includes(status)) {
      return NextResponse.json({ error: 'Estado inválido' }, { status: 400 });
    }

    const redemption = await prisma.redemption.findUnique({ where: { id: params.id } });
    if (!redemption) return NextResponse.json({ error: 'Canje no encontrado' }, { status: 404 });

    if (status === 'CANCELLED' && redemption.status === 'PENDING') {
      // Refund points
      await prisma.customer.update({
        where: { id: redemption.customerId },
        data: { totalPoints: { increment: redemption.pointsSpent } },
      });
      const reward = await prisma.reward.findUnique({ where: { id: redemption.rewardId } });
      if (reward && reward.stock !== -1) {
        await prisma.reward.update({ where: { id: reward.id }, data: { stock: { increment: 1 } } });
      }
    }

    const updated = await prisma.redemption.update({
      where: { id: params.id },
      data: { status, completedAt: status === 'COMPLETED' ? new Date() : undefined },
    });

    return NextResponse.json(updated);
  } catch (error) {
    console.error('Redemption PUT error:', error);
    return NextResponse.json({ error: 'Error al actualizar canje' }, { status: 500 });
  }
}
