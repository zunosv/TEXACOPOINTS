import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import prisma from '@/lib/prisma';

export const dynamic = 'force-dynamic';

export async function GET() {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ error: 'No autorizado' }, { status: 401 });

  try {
    const now = new Date();
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const weekAgo = new Date(today.getTime() - 7 * 24 * 60 * 60 * 1000);
    const monthAgo = new Date(today.getTime() - 30 * 24 * 60 * 60 * 1000);

    const [
      totalCustomers,
      activeCustomers,
      totalStations,
      todayTransactions,
      weekTransactions,
      monthTransactions,
      totalPointsIssued,
      totalPointsRedeemed,
      pendingRedemptions,
      activePromotions,
      tierDistribution,
      recentTransactions,
      dailyPoints,
      topCustomers,
    ] = await Promise.all([
      prisma.customer.count(),
      prisma.customer.count({ where: { status: 'active' } }),
      prisma.station.count({ where: { status: 'active' } }),
      prisma.transaction.aggregate({ where: { date: { gte: today } }, _sum: { pointsEarned: true, amount: true }, _count: true }),
      prisma.transaction.aggregate({ where: { date: { gte: weekAgo } }, _sum: { pointsEarned: true, amount: true }, _count: true }),
      prisma.transaction.aggregate({ where: { date: { gte: monthAgo } }, _sum: { pointsEarned: true, amount: true }, _count: true }),
      prisma.transaction.aggregate({ _sum: { pointsEarned: true } }),
      prisma.redemption.aggregate({ where: { status: 'COMPLETED' }, _sum: { pointsSpent: true } }),
      prisma.redemption.count({ where: { status: 'PENDING' } }),
      prisma.promotion.count({ where: { isActive: true, startDate: { lte: now }, endDate: { gte: now } } }),
      prisma.customer.groupBy({ by: ['tier'], _count: true }),
      prisma.transaction.findMany({ take: 10, orderBy: { date: 'desc' }, include: { customer: { select: { firstName: true, lastName: true } }, station: { select: { name: true } } } }),
      prisma.$queryRaw`
        SELECT DATE(date) as day, SUM("pointsEarned") as points, SUM(amount) as amount, COUNT(*)::int as count
        FROM "Transaction" WHERE date >= ${weekAgo}
        GROUP BY DATE(date) ORDER BY day ASC
      ` as Promise<any[]>,
      prisma.customer.findMany({ take: 5, orderBy: { lifetimePoints: 'desc' }, select: { id: true, firstName: true, lastName: true, totalPoints: true, lifetimePoints: true, tier: true } }),
    ]);

    return NextResponse.json({
      totalCustomers,
      activeCustomers,
      totalStations,
      today: { points: todayTransactions._sum.pointsEarned || 0, amount: todayTransactions._sum.amount || 0, count: todayTransactions._count },
      week: { points: weekTransactions._sum.pointsEarned || 0, amount: weekTransactions._sum.amount || 0, count: weekTransactions._count },
      month: { points: monthTransactions._sum.pointsEarned || 0, amount: monthTransactions._sum.amount || 0, count: monthTransactions._count },
      totalPointsIssued: totalPointsIssued._sum.pointsEarned || 0,
      totalPointsRedeemed: totalPointsRedeemed._sum.pointsSpent || 0,
      pendingRedemptions,
      activePromotions,
      tierDistribution: tierDistribution.map(t => ({ tier: t.tier, count: t._count })),
      recentTransactions,
      dailyPoints: (dailyPoints || []).map((d: any) => ({ day: d.day, points: Number(d.points), amount: Number(d.amount), count: Number(d.count) })),
      topCustomers,
    });
  } catch (error) {
    console.error('Dashboard error:', error);
    return NextResponse.json({ error: 'Error al cargar dashboard' }, { status: 500 });
  }
}
