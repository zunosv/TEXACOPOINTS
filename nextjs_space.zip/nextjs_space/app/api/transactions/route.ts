import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import prisma from '@/lib/prisma';

export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ error: 'No autorizado' }, { status: 401 });

  const { searchParams } = new URL(req.url);
  const customerId = searchParams.get('customerId');
  const stationId = searchParams.get('stationId');
  const days = parseInt(searchParams.get('days') || '30');
  const page = parseInt(searchParams.get('page') || '1');
  const limit = parseInt(searchParams.get('limit') || '50');

  try {
    const since = new Date(Date.now() - days * 24 * 60 * 60 * 1000);
    const where: any = { date: { gte: since } };
    if (customerId) where.customerId = customerId;
    if (stationId) where.stationId = stationId;

    const [transactions, total] = await Promise.all([
      prisma.transaction.findMany({
        where,
        orderBy: { date: 'desc' },
        skip: (page - 1) * limit,
        take: limit,
        include: {
          customer: { select: { firstName: true, lastName: true, phone: true } },
          station: { select: { name: true } },
        },
      }),
      prisma.transaction.count({ where }),
    ]);

    return NextResponse.json({ transactions, total, pages: Math.ceil(total / limit) });
  } catch (error) {
    console.error('Transactions GET error:', error);
    return NextResponse.json({ error: 'Error al obtener transacciones' }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ error: 'No autorizado' }, { status: 401 });

  try {
    const body = await req.json();
    const { customerId, stationId, type, fuelType, gallons, amount, description } = body;

    if (!customerId || !stationId || !type || !amount) {
      return NextResponse.json({ error: 'Campos requeridos: cliente, estación, tipo y monto' }, { status: 400 });
    }

    // Get points config
    const configKey = type === 'FUEL' && fuelType ? fuelType : 'STORE';
    const pointsConfig = await prisma.pointsConfig.findUnique({ where: { fuelType: configKey } });
    const baseRate = pointsConfig?.pointsPerQuetzal || 1;

    // Get customer tier multiplier
    const customer = await prisma.customer.findUnique({ where: { id: customerId } });
    if (!customer) return NextResponse.json({ error: 'Cliente no encontrado' }, { status: 404 });

    const tierConfig = await prisma.tierConfig.findUnique({ where: { name: customer.tier } });
    const tierMultiplier = tierConfig?.multiplier || 1;

    // Check active promotions
    const now = new Date();
    const promotions = await prisma.promotion.findMany({
      where: {
        isActive: true,
        startDate: { lte: now },
        endDate: { gte: now },
        OR: [{ stationId: null }, { stationId }],
        ...(fuelType ? { OR: [{ fuelType: null }, { fuelType }] } : {}),
      },
    });

    let promoMultiplier = 1;
    let promoBonusPoints = 0;
    let promoId: string | undefined;
    for (const promo of promotions) {
      if (promo.minAmount && amount < promo.minAmount) continue;
      if (promo.type === 'MULTIPLIER' || promo.type === 'DOUBLE_POINTS') {
        promoMultiplier = Math.max(promoMultiplier, promo.multiplier);
        promoId = promo.id;
      }
      if (promo.type === 'BONUS_POINTS') {
        promoBonusPoints += promo.bonusPoints;
        promoId = promo.id;
      }
    }

    const totalMultiplier = tierMultiplier * promoMultiplier;
    const pointsEarned = Math.floor(amount * baseRate * totalMultiplier) + promoBonusPoints;

    const transaction = await prisma.transaction.create({
      data: {
        customerId,
        stationId,
        type,
        fuelType: fuelType || null,
        gallons: gallons || null,
        amount,
        pointsEarned,
        multiplier: totalMultiplier,
        promotionId: promoId || null,
        description,
      },
    });

    // Update customer points
    const newLifetime = customer.lifetimePoints + pointsEarned;
    // Check tier upgrade
    const tiers = await prisma.tierConfig.findMany({ orderBy: { minPoints: 'desc' } });
    let newTier = customer.tier;
    for (const t of tiers) {
      if (newLifetime >= t.minPoints) {
        newTier = t.name;
        break;
      }
    }

    await prisma.customer.update({
      where: { id: customerId },
      data: {
        totalPoints: { increment: pointsEarned },
        lifetimePoints: { increment: pointsEarned },
        lastVisit: now,
        tier: newTier,
      },
    });

    return NextResponse.json({ ...transaction, tierUpgrade: newTier !== customer.tier ? newTier : null }, { status: 201 });
  } catch (error) {
    console.error('Transaction POST error:', error);
    return NextResponse.json({ error: 'Error al registrar transacción' }, { status: 500 });
  }
}
