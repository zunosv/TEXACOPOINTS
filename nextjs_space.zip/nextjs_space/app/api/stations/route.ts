import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import prisma from '@/lib/prisma';

export const dynamic = 'force-dynamic';

export async function GET() {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ error: 'No autorizado' }, { status: 401 });

  try {
    const stations = await prisma.station.findMany({
      orderBy: { name: 'asc' },
      include: { _count: { select: { transactions: true } } },
    });
    return NextResponse.json(stations);
  } catch (error) {
    console.error('Stations GET error:', error);
    return NextResponse.json({ error: 'Error al obtener estaciones' }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ error: 'No autorizado' }, { status: 401 });

  try {
    const body = await req.json();
    const { name, address, city, phone, manager } = body;
    if (!name || !address || !city) return NextResponse.json({ error: 'Nombre, dirección y ciudad son requeridos' }, { status: 400 });

    const station = await prisma.station.create({ data: { name, address, city, phone, manager } });
    return NextResponse.json(station, { status: 201 });
  } catch (error) {
    console.error('Stations POST error:', error);
    return NextResponse.json({ error: 'Error al crear estación' }, { status: 500 });
  }
}
