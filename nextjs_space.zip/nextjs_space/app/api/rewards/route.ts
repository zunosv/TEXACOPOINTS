import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import prisma from '@/lib/prisma';

export const dynamic = 'force-dynamic';

export async function GET() {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ error: 'No autorizado' }, { status: 401 });

  try {
    const rewards = await prisma.reward.findMany({
      orderBy: { pointsCost: 'asc' },
      include: { _count: { select: { redemptions: true } } },
    });
    return NextResponse.json(rewards);
  } catch (error) {
    console.error('Rewards GET error:', error);
    return NextResponse.json({ error: 'Error al obtener recompensas' }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ error: 'No autorizado' }, { status: 401 });

  try {
    const body = await req.json();
    const { name, description, pointsCost, category, stock, validUntil } = body;
    if (!name || !pointsCost || !category) return NextResponse.json({ error: 'Nombre, costo y categoría son requeridos' }, { status: 400 });

    const reward = await prisma.reward.create({
      data: {
        name,
        description,
        pointsCost: parseInt(pointsCost),
        category,
        stock: stock !== undefined ? parseInt(stock) : -1,
        validUntil: validUntil ? new Date(validUntil) : null,
      },
    });
    return NextResponse.json(reward, { status: 201 });
  } catch (error) {
    console.error('Rewards POST error:', error);
    return NextResponse.json({ error: 'Error al crear recompensa' }, { status: 500 });
  }
}
