import { CustomersContent } from './_components/customers-content'
export const dynamic = 'force-dynamic'
export default function CustomersPage() { return <CustomersContent /> }
