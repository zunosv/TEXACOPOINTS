'use client'

import { useEffect, useState } from 'react'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { toast } from 'sonner'
import { MapPin, Plus, Edit, Trash2, Phone, User } from 'lucide-react'

export function StationsContent() {
  const [stations, setStations] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [dialogOpen, setDialogOpen] = useState(false)
  const [editing, setEditing] = useState<any>(null)
  const [form, setForm] = useState({ name: '', address: '', city: '', phone: '', manager: '' })

  const fetchStations = () => {
    fetch('/api/stations').then(r => r.json()).then(setStations).catch(() => toast.error('Error')).finally(() => setLoading(false))
  }

  useEffect(() => { fetchStations() }, [])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    try {
      const url = editing ? `/api/stations/${editing.id}` : '/api/stations'
      const method = editing ? 'PUT' : 'POST'
      const res = await fetch(url, { method, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(form) })
      const data = await res.json()
      if (!res.ok) { toast.error(data.error); return }
      toast.success(editing ? 'Estación actualizada' : 'Estación creada')
      setDialogOpen(false)
      setEditing(null)
      setForm({ name: '', address: '', city: '', phone: '', manager: '' })
      fetchStations()
    } catch { toast.error('Error') }
  }

  const handleEdit = (s: any) => {
    setEditing(s)
    setForm({ name: s.name, address: s.address, city: s.city, phone: s.phone || '', manager: s.manager || '' })
    setDialogOpen(true)
  }

  const handleDelete = async (id: string) => {
    if (!confirm('¿Eliminar esta estación?')) return
    await fetch(`/api/stations/${id}`, { method: 'DELETE' })
    toast.success('Estación eliminada')
    fetchStations()
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="font-display text-2xl font-bold tracking-tight flex items-center gap-2">
            <MapPin className="w-6 h-6 text-primary" /> Estaciones TEXACO
          </h2>
          <p className="text-sm text-muted-foreground mt-1">Gestiona las estaciones del programa</p>
        </div>
        <Dialog open={dialogOpen} onOpenChange={(open) => { setDialogOpen(open); if (!open) { setEditing(null); setForm({ name: '', address: '', city: '', phone: '', manager: '' }) } }}>
          <DialogTrigger asChild>
            <Button><Plus className="w-4 h-4 mr-2" /> Nueva Estación</Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader><DialogTitle>{editing ? 'Editar Estación' : 'Nueva Estación'}</DialogTitle></DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2"><Label>Nombre *</Label><Input value={form.name} onChange={(e: any) => setForm({ ...form, name: e.target.value })} required placeholder="TEXACO Zona 10" /></div>
              <div className="space-y-2"><Label>Dirección *</Label><Input value={form.address} onChange={(e: any) => setForm({ ...form, address: e.target.value })} required /></div>
              <div className="space-y-2"><Label>Ciudad *</Label><Input value={form.city} onChange={(e: any) => setForm({ ...form, city: e.target.value })} required /></div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2"><Label>Teléfono</Label><Input value={form.phone} onChange={(e: any) => setForm({ ...form, phone: e.target.value })} /></div>
                <div className="space-y-2"><Label>Gerente</Label><Input value={form.manager} onChange={(e: any) => setForm({ ...form, manager: e.target.value })} /></div>
              </div>
              <Button type="submit" className="w-full">{editing ? 'Actualizar' : 'Crear'}</Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {[...Array(3)].map((_, i) => <Card key={i} className="animate-pulse"><CardContent className="p-6"><div className="h-24 bg-muted rounded" /></CardContent></Card>)}
        </div>
      ) : stations.length === 0 ? (
        <Card><CardContent className="p-12 text-center"><MapPin className="w-12 h-12 mx-auto text-muted-foreground mb-3" /><p className="text-muted-foreground">No hay estaciones registradas</p></CardContent></Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {stations.map(s => (
            <Card key={s.id} className="hover:shadow-md transition-shadow">
              <CardContent className="p-5">
                <div className="flex items-start justify-between mb-3">
                  <h3 className="font-semibold text-base">{s.name}</h3>
                  <Badge variant={s.status === 'active' ? 'default' : 'secondary'}>{s.status === 'active' ? 'Activa' : 'Inactiva'}</Badge>
                </div>
                <p className="text-sm text-muted-foreground mb-1">{s.address}</p>
                <p className="text-sm text-muted-foreground mb-3">{s.city}</p>
                {s.phone && <div className="flex items-center gap-1 text-xs text-muted-foreground mb-1"><Phone className="w-3 h-3" />{s.phone}</div>}
                {s.manager && <div className="flex items-center gap-1 text-xs text-muted-foreground mb-3"><User className="w-3 h-3" />{s.manager}</div>}
                <p className="text-xs text-muted-foreground mb-3">{s._count?.transactions || 0} transacciones registradas</p>
                <div className="flex gap-2">
                  <Button variant="outline" size="sm" onClick={() => handleEdit(s)} className="flex-1"><Edit className="w-3 h-3 mr-1" /> Editar</Button>
                  <Button variant="outline" size="sm" onClick={() => handleDelete(s.id)} className="text-destructive hover:text-destructive"><Trash2 className="w-3 h-3" /></Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}
