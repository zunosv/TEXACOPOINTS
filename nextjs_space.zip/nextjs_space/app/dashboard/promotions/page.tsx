import { PromotionsContent } from './_components/promotions-content'
export const dynamic = 'force-dynamic'
export default function PromotionsPage() { return <PromotionsContent /> }
