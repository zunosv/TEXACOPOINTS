'use client'

import { useEffect, useState } from 'react'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Switch } from '@/components/ui/switch'
import { toast } from 'sonner'
import { Megaphone, Plus, Edit, Trash2, Calendar, Zap } from 'lucide-react'

const PROMO_TYPES = [
  { value: 'MULTIPLIER', label: 'Multiplicador de Puntos' },
  { value: 'BONUS_POINTS', label: 'Puntos Bonus' },
  { value: 'DOUBLE_POINTS', label: 'Puntos Dobles' },
]

const FUEL_TYPES = ['REGULAR', 'PREMIUM', 'DIESEL']

export function PromotionsContent() {
  const [promotions, setPromotions] = useState<any[]>([])
  const [stations, setStations] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [dialogOpen, setDialogOpen] = useState(false)
  const [editing, setEditing] = useState<any>(null)
  const [form, setForm] = useState({ name: '', description: '', type: 'MULTIPLIER', multiplier: '2', bonusPoints: '0', minAmount: '', fuelType: '', stationId: '', startDate: '', endDate: '' })

  const fetchPromotions = () => {
    fetch('/api/promotions').then(r => r.json()).then(setPromotions).catch(() => toast.error('Error')).finally(() => setLoading(false))
  }

  useEffect(() => { fetchPromotions() }, [])
  useEffect(() => { fetch('/api/stations').then(r => r.json()).then(setStations) }, [])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    try {
      const url = editing ? `/api/promotions/${editing.id}` : '/api/promotions'
      const method = editing ? 'PUT' : 'POST'
      const res = await fetch(url, { method, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(form) })
      const data = await res.json()
      if (!res.ok) { toast.error(data.error); return }
      toast.success(editing ? 'Promoción actualizada' : 'Promoción creada')
      setDialogOpen(false)
      setEditing(null)
      setForm({ name: '', description: '', type: 'MULTIPLIER', multiplier: '2', bonusPoints: '0', minAmount: '', fuelType: '', stationId: '', startDate: '', endDate: '' })
      fetchPromotions()
    } catch { toast.error('Error') }
  }

  const handleEdit = (p: any) => {
    setEditing(p)
    setForm({
      name: p.name, description: p.description || '', type: p.type,
      multiplier: String(p.multiplier), bonusPoints: String(p.bonusPoints), minAmount: p.minAmount ? String(p.minAmount) : '',
      fuelType: p.fuelType || '', stationId: p.stationId || '',
      startDate: p.startDate ? p.startDate.split('T')[0] : '', endDate: p.endDate ? p.endDate.split('T')[0] : '',
    })
    setDialogOpen(true)
  }

  const handleToggle = async (p: any) => {
    await fetch(`/api/promotions/${p.id}`, { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ isActive: !p.isActive }) })
    fetchPromotions()
  }

  const handleDelete = async (id: string) => {
    if (!confirm('¿Eliminar esta promoción?')) return
    await fetch(`/api/promotions/${id}`, { method: 'DELETE' })
    toast.success('Promoción eliminada')
    fetchPromotions()
  }

  const isPromoActive = (p: any) => {
    const now = new Date()
    return p.isActive && new Date(p.startDate) <= now && new Date(p.endDate) >= now
  }

  const typeLabel = (type: string) => PROMO_TYPES.find(t => t.value === type)?.label || type

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="font-display text-2xl font-bold tracking-tight flex items-center gap-2">
            <Megaphone className="w-6 h-6 text-primary" /> Promociones
          </h2>
          <p className="text-sm text-muted-foreground mt-1">Crea campañas para multiplicar puntos y aumentar la fidelización</p>
        </div>
        <Dialog open={dialogOpen} onOpenChange={(open) => { setDialogOpen(open); if (!open) { setEditing(null); setForm({ name: '', description: '', type: 'MULTIPLIER', multiplier: '2', bonusPoints: '0', minAmount: '', fuelType: '', stationId: '', startDate: '', endDate: '' }) } }}>
          <DialogTrigger asChild>
            <Button><Plus className="w-4 h-4 mr-2" /> Nueva Promoción</Button>
          </DialogTrigger>
          <DialogContent className="max-w-lg">
            <DialogHeader><DialogTitle>{editing ? 'Editar Promoción' : 'Nueva Promoción'}</DialogTitle></DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2"><Label>Nombre *</Label><Input value={form.name} onChange={(e: any) => setForm({ ...form, name: e.target.value })} required placeholder="Puntos Dobles en Premium" /></div>
              <div className="space-y-2"><Label>Descripción</Label><Input value={form.description} onChange={(e: any) => setForm({ ...form, description: e.target.value })} /></div>
              <div className="space-y-2">
                <Label>Tipo *</Label>
                <Select value={form.type} onValueChange={v => setForm({ ...form, type: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{PROMO_TYPES.map(t => <SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              {(form.type === 'MULTIPLIER' || form.type === 'DOUBLE_POINTS') && (
                <div className="space-y-2"><Label>Multiplicador</Label><Input type="number" step="0.1" value={form.multiplier} onChange={(e: any) => setForm({ ...form, multiplier: e.target.value })} /></div>
              )}
              {form.type === 'BONUS_POINTS' && (
                <div className="space-y-2"><Label>Puntos Bonus</Label><Input type="number" value={form.bonusPoints} onChange={(e: any) => setForm({ ...form, bonusPoints: e.target.value })} /></div>
              )}
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2"><Label>Monto mínimo (Q)</Label><Input type="number" step="0.01" value={form.minAmount} onChange={(e: any) => setForm({ ...form, minAmount: e.target.value })} /></div>
                <div className="space-y-2">
                  <Label>Tipo Combustible</Label>
                  <Select value={form.fuelType} onValueChange={v => setForm({ ...form, fuelType: v })}>
                    <SelectTrigger><SelectValue placeholder="Todos" /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value=" ">Todos</SelectItem>
                      {FUEL_TYPES.map(f => <SelectItem key={f} value={f}>{f}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="space-y-2">
                <Label>Estación específica</Label>
                <Select value={form.stationId} onValueChange={v => setForm({ ...form, stationId: v })}>
                  <SelectTrigger><SelectValue placeholder="Todas las estaciones" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value=" ">Todas</SelectItem>
                    {stations.map(s => <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2"><Label>Fecha Inicio *</Label><Input type="date" value={form.startDate} onChange={(e: any) => setForm({ ...form, startDate: e.target.value })} required /></div>
                <div className="space-y-2"><Label>Fecha Fin *</Label><Input type="date" value={form.endDate} onChange={(e: any) => setForm({ ...form, endDate: e.target.value })} required /></div>
              </div>
              <Button type="submit" className="w-full">{editing ? 'Actualizar' : 'Crear'}</Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {[...Array(2)].map((_, i) => <Card key={i} className="animate-pulse"><CardContent className="p-6"><div className="h-28 bg-muted rounded" /></CardContent></Card>)}
        </div>
      ) : promotions.length === 0 ? (
        <Card><CardContent className="p-12 text-center"><Megaphone className="w-12 h-12 mx-auto text-muted-foreground mb-3" /><p className="text-muted-foreground">No hay promociones creadas</p></CardContent></Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {promotions.map(p => (
            <Card key={p.id} className={`hover:shadow-md transition-shadow ${!p.isActive ? 'opacity-60' : ''}`}>
              <CardContent className="p-5">
                <div className="flex items-start justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <Badge variant={isPromoActive(p) ? 'default' : 'secondary'}>
                      {isPromoActive(p) ? 'Activa' : p.isActive ? 'Programada' : 'Inactiva'}
                    </Badge>
                    <Badge variant="outline" className="text-xs">{typeLabel(p.type)}</Badge>
                  </div>
                  <Switch checked={p.isActive} onCheckedChange={() => handleToggle(p)} />
                </div>
                <h3 className="font-semibold text-base mb-1">{p.name}</h3>
                {p.description && <p className="text-sm text-muted-foreground mb-2">{p.description}</p>}
                <div className="flex items-center gap-3 text-sm mb-2">
                  {(p.type === 'MULTIPLIER' || p.type === 'DOUBLE_POINTS') && (
                    <span className="flex items-center gap-1 font-semibold text-primary"><Zap className="w-4 h-4" /> x{p.multiplier}</span>
                  )}
                  {p.type === 'BONUS_POINTS' && (
                    <span className="flex items-center gap-1 font-semibold text-amber-500">+{p.bonusPoints} pts</span>
                  )}
                  {p.fuelType && <Badge variant="outline" className="text-xs">{p.fuelType}</Badge>}
                  {p.station && <span className="text-xs text-muted-foreground">{p.station.name}</span>}
                </div>
                <div className="flex items-center gap-1 text-xs text-muted-foreground mb-3">
                  <Calendar className="w-3 h-3" />
                  {new Date(p.startDate).toLocaleDateString('es-GT')} - {new Date(p.endDate).toLocaleDateString('es-GT')}
                </div>
                <div className="flex gap-2">
                  <Button variant="outline" size="sm" onClick={() => handleEdit(p)} className="flex-1"><Edit className="w-3 h-3 mr-1" /> Editar</Button>
                  <Button variant="outline" size="sm" onClick={() => handleDelete(p.id)} className="text-destructive hover:text-destructive"><Trash2 className="w-3 h-3" /></Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}
