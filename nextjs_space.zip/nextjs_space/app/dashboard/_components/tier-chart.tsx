'use client'

import { ResponsiveContainer, PieChart, Pie, Cell, Tooltip, Legend } from 'recharts'

const TIER_COLORS: Record<string, string> = {
  BRONCE: '#CD7F32',
  PLATA: '#C0C0C0',
  ORO: '#B8860B',
  PLATINO: '#7B7B7B',
}

export default function TierChart({ data }: { data: any[] }) {
  if (!data || data.length === 0) {
    return <div className="flex items-center justify-center h-[250px] text-sm text-muted-foreground">Sin datos aún</div>
  }

  const chartData = data.map(d => ({
    name: d.tier,
    value: d.count,
    color: TIER_COLORS[d.tier] || '#94a3b8',
  }))

  return (
    <ResponsiveContainer width="100%" height={250}>
      <PieChart>
        <Pie data={chartData} dataKey="value" nameKey="name" cx="50%" cy="50%" innerRadius={60} outerRadius={90} paddingAngle={4}>
          {chartData.map((entry, i) => (
            <Cell key={i} fill={entry.color} />
          ))}
        </Pie>
        <Tooltip formatter={(value: number) => [value, 'Clientes']} />
        <Legend />
      </PieChart>
    </ResponsiveContainer>
  )
}
