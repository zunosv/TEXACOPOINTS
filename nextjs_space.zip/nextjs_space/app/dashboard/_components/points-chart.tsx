'use client'

import { ResponsiveContainer, AreaChart, Area, XAxis, YAxis, Tooltip } from 'recharts'

export default function PointsChart({ data }: { data: any[] }) {
  if (!data || data.length === 0) {
    return <div className="flex items-center justify-center h-[250px] text-sm text-muted-foreground">Sin datos aún</div>
  }

  const formatted = data.map(d => ({
    ...d,
    day: new Date(d.day).toLocaleDateString('es-GT', { weekday: 'short', day: 'numeric' }),
  })).sort((a, b) => new Date(a.day).getTime() - new Date(b.day).getTime())

  return (
    <ResponsiveContainer width="100%" height={250}>
      <AreaChart data={formatted}>
        <defs>
          <linearGradient id="colorPoints" x1="0" y1="0" x2="0" y2="1">
            <stop offset="5%" stopColor="hsl(358, 88%, 52%)" stopOpacity={0.3} />
            <stop offset="95%" stopColor="hsl(358, 88%, 52%)" stopOpacity={0} />
          </linearGradient>
        </defs>
        <XAxis dataKey="day" tick={{ fontSize: 12 }} tickLine={false} axisLine={false} />
        <YAxis tick={{ fontSize: 12 }} tickLine={false} axisLine={false} />
        <Tooltip
          contentStyle={{ borderRadius: '8px', border: '1px solid hsl(0 0% 89%)', fontSize: '13px' }}
          formatter={(value: number) => [value.toLocaleString('es-GT'), 'Puntos']}
        />
        <Area type="monotone" dataKey="points" stroke="hsl(358, 88%, 52%)" fill="url(#colorPoints)" strokeWidth={2} />
      </AreaChart>
    </ResponsiveContainer>
  )
}
